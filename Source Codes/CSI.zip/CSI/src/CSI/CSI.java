/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CSI;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import org.securedt.CaptureScreen;
import org.securedt.Keylog;

/*
Pls note: if you wish to include all the jar files in the project library into the jar when building it, 
go to Files->right click the build.xml
 - Run Target->Other Target->Package-for-store
and get the complete jar file from a folder called "store" instead of inside the "dist" folder
Your welcome.
 *
 *
 * @author Ayu, P1444968
 */
public class CSI {
    private final ConcurrentLinkedQueue<String> commonQ = new ConcurrentLinkedQueue();
    final String serverip = "192.168.237.138"; //set to 192.168.237.138 or localhost (for development)
    
    static JPanel container;
    static CardLayout cl;
    Integer PING_TIMEOUT = 5000; //ping timeout
    JPanel connectPanel;
    JFrame mFrame;

    String message = "";
    Socket s = null;
    CaptureScreen cs = null;
    Keylog kl;
    private int stopFlag = 0;
    private boolean setBeat = true;
    boolean logging = false;

    //hardcoded urls, may want to change this to get urls frm the db
    //on the server side
    //to test connection to various IP
    private final String testing_urls[] = { //supposed to be empty 
           "www.facebook.com",
            "192.168.137.2",
            "192.168.237.241"};
    //the expected value each IP/urls it shld return
    private final boolean expected_results[] = { //supposed to be empty
            false,
            true,
            false};
    private boolean [] ping_results = new boolean[3];
     
    JButton button;
    public CSI() {
        mFrame = new JFrame("Secured-T");
        JTextField textField = new JTextField();
        JLabel label = new JLabel("Enter Admission Number (e.g P1234567): ");
        button = new JButton("Connect");

        textField.setPreferredSize(new Dimension(200, 25));

        cl = new CardLayout(5, 5);
        container = new JPanel(cl);
        container.setBackground(Color.black);

        connectPanel = new JPanel();
        connectPanel.setBackground(Color.GRAY);
        connectPanel.add(label);
        connectPanel.add(textField);
        connectPanel.add(button);

        container.add(connectPanel, "connect");

        button.addActionListener((ActionEvent e) -> {
            String adminNo = textField.getText();
            //goes to serverconnect to start connection
            serverConnect(adminNo); /*adminNo.substring(0,8)*/
            button.setEnabled(false);
        });
        //when window closes, set stopFlag to 1
        //everything will end
        mFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                System.out.println("setting stopFlag to 1 before exit");
                stopFlag = 1;
            }
        });

        mFrame.add(container);
        cl.show(container, "connect");
        mFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        mFrame.setResizable(false);
        mFrame.pack();
        mFrame.setVisible(true);

    }
    //To close the connection of the client to the server
    private void stopConnection(BufferedReader in, PrintWriter out) {
        this.stopFlag = 1;
        if (this.s != null) {
            System.out.println("Close the connection");
            try {
                in.close();
                out.close();
                s.close();
            } catch (IOException ex) {
                Logger.getLogger(CSI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.exit(0);
    }

    //To check if cs is null
    private boolean csIsNull() {
        return (this.cs == null);
    }
    
    //To check if kl is null
    private boolean klIsNull() {
        return (this.kl == null);
    }

    //To stop the logging 
    private void stopLog() {
        if (!csIsNull() /*&& !klIsNull()*/) {
            this.cs.stopFlag2 = 1;
            this.kl.stopFlag3 = 1;
           // this.cs=null; call this too early may crash the cs.
        } else {
            System.out.println("Serious error. Illegal call to stop log.");
        }
    }

//    log when cheating and upon disonnection
    public void logCase() {
        if (this.logging == true){
            return; //already in logging state
        }
        
        this.logging = true;
//        System.out.println("student is cheating");
        this.cs = new CaptureScreen();
        this.cs.stopFlag2 = 0;
        new Thread(() -> {
            this.cs.startcapture();
        }).start();
           
        this.kl = new Keylog();
        this.kl.stopFlag3 = 0;
        new Thread(() -> {
            try {
            kl.startKeyLog();
            } catch (FileNotFoundException | InterruptedException ex) {
                Logger.getLogger(CSI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();
    }

    //connects to the server and starts all the threads
    public void serverConnect(String adminNo) {
        if(adminNo.equals("") || adminNo.length() < 8 || adminNo.length() > 8){
            JOptionPane.showMessageDialog(null, "Please enter a valid admission number!", "Secured-T", JOptionPane.ERROR_MESSAGE);
            mFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            return;
        }
 
        try {
            this.s = new Socket(this.serverip, 8808);
            BufferedReader in
                    = new BufferedReader(
                            new InputStreamReader(s.getInputStream()));
            PrintWriter out
                    = new PrintWriter(s.getOutputStream(), true);

            if (s.isClosed() == false) {
                // connection is okay now.
                // using a seperate thread to keep sending 
                // heartbeats
                JOptionPane.showMessageDialog(null, "You have successfully connected!", "Secured-T", JOptionPane.INFORMATION_MESSAGE);
//                mFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                mFrame.dispose();
                mFrame.setUndecorated(true);
                mFrame.setVisible(true);
                mFrame.pack();

                this.stopFlag = 0;
                
                new Thread(() -> {
                    this.startHeartBeat(s, in, out, adminNo);
                }).start();
                
                // here we shall start off all the other threads that 
                // handle screencapture , policing, and/or key logging.
                // set up one thread to listen to server's command
                new Thread(() -> {
                    this.listenToServerCmd(in, out);
                }).start();
                
                for (int i = 0; i < this.testing_urls.length ;i++) {
//                    String url = this.testing_urls[i];
                    final int index = i; 
//                    boolean expected_val = this.expected_results[i];
                    new Thread(() -> {
                    this.startPolicing(index); 
                }).start();
                }
//            } else {
//                logCase();
//                
//                
            }
        } catch (IOException i) {
            System.out.println(i);
            JOptionPane.showMessageDialog(null, "Connection error, please inform your lecturer!", "Secured-T", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void startAll(Socket s, BufferedReader in, PrintWriter out, String adminNo){
//        new Thread(() -> {
//            this.startHeartBeat(s, in, out, adminNo);
//        }).start();
                
        // here we shall start off all the other threads that 
        // handle screencapture , policing, and/or key logging.
        // set up one thread to listen to server's command
        new Thread(() -> {
            this.listenToServerCmd(in, out);
        }).start();

        for (int i = 0; i < this.testing_urls.length ;i++) {
//                    String url = this.testing_urls[i];
            final int index = i; 
//                    boolean expected_val = this.expected_results[i];
            new Thread(() -> {
            this.startPolicing(index); 
        }).start();
        }
    }

    private void listenToServerCmd(BufferedReader in, PrintWriter out) {
        String resp="";
        while (this.stopFlag != 1) {
            try {
                if (in != null) {
                    System.out.println("pending for server commands");
                    resp = in.readLine();
//                    System.out.println(resp);
                    
                    if(resp.equals("demand")){
                        System.out.println("Demand to log student");
                    //1/8 10:21 am -> will put the demand into a queue.
                    //will only be listening, not setting anything. 
                        this.commonQ.add("demand");
                        
                    } else if (resp.equals("nodemand")) { //resp = "nodemand"
                        if(this.logging == true){
                            stopLog();
                            try{
                                Thread.sleep(3000); //waiting for the cs to stop
                            } catch (InterruptedException ee) {
                                System.out.println(ee);
                            }
                            
                            //set logging to false
                            this.logging = false;
                            System.out.println("Stop demand to log");
                        }
                    } //else { //asked to terminate
//                        stopConnection(in, out);
//                    }
                } else {
                    System.out.println("Command is null");
                }
            } catch (IOException ex) {
                Logger.getLogger(CSI.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println(ex);
                this.stopFlag = 1;
            }
        }
        System.out.println("Stop listening to server command");
    }

    private void startHeartBeat(Socket s, BufferedReader in, PrintWriter out, String adminNo) {
        //To change body of generated methods, choose Tools | Templates.
        //For now, just keep sending heartbeats for every 8 seconds.
        //will check from queue to look for msg to send to server
        System.out.println("startHearBeat");
        String mesgToServer = null;
        out.print(adminNo);
        out.flush();

        while (this.stopFlag != 1) {
            try{
                if (setBeat == true){ 
                    setBeat = false;
                    Thread.sleep(8000);
                }
//                System.out.println(this.commonQ);
                // moving the sleep at the top of the loop, helps to seperate the messages. 
                // adminNo and OK will not be mixed up
                //will send adminNo then sleep
                // add in the check queue and send mesg here.
                if (!this.commonQ.isEmpty()){
                    mesgToServer = commonQ.poll();
                    if (mesgToServer != null) {
                        if (mesgToServer.equals("cheat")){
                            // need to report the Server.
                            out.print(mesgToServer);
                            out.flush();
                            System.out.println("Cheating get from queue");
                    //1/8 10:29am -> will just send to logcase. 
                    //within logcase, they will check if it is being started or not.
                            logCase();
                        } else { //demand from server
                            logCase();
                            out.print("OK");
                            out.flush();
                        }
                    }
                } else {
                    //no cheat in queue, so report normal to Server
                    System.out.println("ALL is ok");
                    mesgToServer = "OK";
                    out.print(mesgToServer);
                    out.flush();                   
                    //31/7 1:50pm - will not stop logging automatically
                    //the logging will only stop upon demand from server
                }
                 //will sleep fr 8 seconds
                Thread.sleep(8000);
               
            } catch (InterruptedException ee) {
                this.stopFlag = 1; // time to terminate
            }
        }
        //to start logging when student changes network
//        logCase();

//        //stop connection
        stopConnection(in, out);
//        System.out.println("Server connect thread ends here. Heartbeat Stopped");
    }
    
    private boolean pingnow(String ip) {
        boolean retval=false;
        try {
            InetAddress address = InetAddress.getByName(ip);
            retval = address.isReachable(this.PING_TIMEOUT);
        } catch (IOException ex) {
            System.out.println(ip + ex.getMessage());
             
        } finally {
//            System.out.println("accessing to "+ip+" is "+ retval);
            return retval;
        }
    }
    
    private void startPolicing(/*String url*/int index) {
        // This function will be run in separate thread
        // It will check if the host can ping the specific url given.
        // This method will use a commonQueue to report a 
        // cheating case, if the ping result does not match with
        // the expectedValue.
        String url = testing_urls[index];
        boolean expectedValue = expected_results[index];
        
        while (this.stopFlag!=1) {
            try {
//                System.out.println("Here I police" + url);
                boolean ping = pingnow(url);
                if (ping != expectedValue) {
                    System.out.println("Something Wrong detected related to "+url+" by SPAI");
                } /*else {*/
//                    System.out.println(url+" reports normal");
//                }

                ping_results[index] = ping;
                checkResults();

                System.out.println("Sleeping in "+url);
                Thread.sleep(15000);
            } catch (InterruptedException ee) {
                this.stopFlag = 1; // time to terminate
            }
        }
        System.out.println("outside loop");
    }
    
    private void checkResults(){
        int err_count = 0;
        for (int i = 0; i < this.ping_results.length ;i++) {
            boolean expected_val = this.expected_results[i];
            if (this.ping_results[i] != expected_val){
                err_count++;
            }
        }
        System.out.println(err_count);
        if(err_count == 3){
            System.out.println("3 pings are wrong");
            this.commonQ.add("cheat");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(CSI::new);
    }
}

//connection is lost when client changes network, aka disconnected from the server.
//hence, cannot do the logging. But it can detect when someone cheats in another manner, while still being connected to the server somehow 
//may want to try to retry to connect to the server whenever it looses connection to the server,
//since server side, when it doesnt receive anything from the client, it times out.