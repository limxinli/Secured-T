package org.securedt;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class CaptureScreen {

    int count = 1;
    public int stopFlag2 = 0;
    
    private static final SimpleDateFormat date = new SimpleDateFormat ("yyyy-MM-dd HH.mm.ss");

    public CaptureScreen() {
        // constructor
        File directory = new File(String.valueOf("screenshots"));

        if (!directory.exists()) {
            directory.mkdir();

        }
        System.out.println("storage folder: "+directory.getAbsolutePath());
    }

    public void startcapture() {
       // this.stopFlag2 = 0;
        while (this.stopFlag2 != 1) {
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            System.out.println("stopFlag is " + this.stopFlag2);
            this.saveScreenshot("screenshots/screen_" + date.format(timestamp) + ".png");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }//while
        // exit and stop.
    }

//    public void stopCapture() {
//        System.out.println("entering stopCapture");
//        this.stopFlag2 = 1;
//    }

    public void saveScreenshot(String fileName) {

        try {
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Rectangle screenRectangle = new Rectangle(screenSize);
            Robot robot = new Robot();
            BufferedImage image = robot.createScreenCapture(screenRectangle);
            ImageIO.write(image, "png", new File(fileName));
            System.out.println("saved.." + fileName);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

//    public static void main(String[] args) {
//        CaptureScreen cs = new CaptureScreen();
//        new Thread(() -> {
//            cs.startcapture();
//        }).start();
//        System.out.println("Screen capture has been started !");
//        // now delay for 20 seconds then stop the thread.
//        try {
//            Thread.sleep(20000);
//
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//            cs.stopCapture();
//        }
//        cs.stopCapture();
//    }
}
